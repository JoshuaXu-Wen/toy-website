<# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#
#  Script Name     :  GetDiscoveryDataExchangeOnPrem.ps1
#  Creation Date   :  2021-01-20    Rusty Ramser (Inde Technology Limited)
#  Version Info    :  01 - Date  :  2021-02-12
#                          Author:  Rusty Ramser (Inde Technology Limited)
#                          Notes :  Original script functionality and release.
#                     02 - Date  :  2021-04-07
#                          Author:  Rusty Ramser (Inde Technology Limited)
#                          Notes :  Added validation check for Active Directory module so Get-ADUser functions.
#                     03 - Date  :  2021-05-12
#                          Author:  Rusty Ramser (Inde Technology Limited)
#                          Notes :  Added Distribution Group (DL) data gathering.
#                     04 - Date  :  2021-07-27
#                          Author:  Rusty Ramser (Inde Technology Limited)
#                          Notes :  Added a function to get Public Folder information.  If working in an Exchange 2010
#                                   environment where PFs exist, the main program can be modified to make a call to
#                                   this function.
#                     05 - Date  :  
#                          Author:  
#                          Notes :  
#
#  Purpose         :  This script gathers discovery data for an Exchange on-premises environment. 
#
#  Requirements    -  PowerShell v5.0 or higher.
#                  -  Run on a domain member computer with the Active Directory PowerShell module installed and
#                     imported.  (Note:  Exchange 2010's EMS does not import the AD module by default.  Import manually
#                     and the validation check will pass.)
#                  -  Run on an Exchange server or domain member computer with Exchange PowerShell module (Exchange
#                     Management Shell) installed.  (Correct domain and domain controller communication is assumed.)
#                  -  User credentials running the script is a member of the Exchange Organization Management role
#                     group and a member of the Domain Admins security group (or permissions to read Active Directory).
#                  -  Script run in the Exchange Management Shell (EMS).
#                  -  Writable C:\Scripts directory for logging.  (Directory path is a variable that can be modified.)
#
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #>


#
# Variable declarations and initialisation.
$LogPath = "C:\Scripts\"


function f_ValidateAdModule {
   # Validate the AD module is available.
   try {
      $Testing = Get-ADDomain
   }
   catch {
      Write-Host -ForegroundColor Red -NoNewline "Error  :  "
      Write-Host "The Active Directory PowerShell module is required for this script!"
      Write-Host "Info   :  Run on a system which has this module installed or install RSAT tools locally."
      Write-Host -ForegroundColor Red -NoNewline "STATUS :  "
      Write-Host "Exiting script.`n"
      break
   }
}   # end function f_ValidateAdModule


function f_ValidateEMS {
   # Validate the Exchange Management Shell (EMS) is running.
   if (!$exscripts) {
      Write-Host -ForegroundColor Red -NoNewline "Error  :  "
      Write-Host "Script must be run from the Exchange Management Shell!"
      Write-Host -ForegroundColor Red -NoNewline "STATUS :  "
      Write-Host "Exiting script.`n"
      break
   }   # end if (!$exscripts)
}   # end function f_ValidateEMS


function f_ValidateLogFilePath {
   if (!(Test-Path -Path $LogPath)) {
      try {
         Invoke-Expression "md $LogPath" | Out-Null
      }
      catch {
         Write-Host -ForegroundColor Red -NoNewline "Error  :  "
         Write-Host "Log file path does not exist and could not be created!"
         Write-Host -ForegroundColor Red -NoNewline "STATUS :  "
         Write-Host "Exiting script.`n"
         break
      }
   }   # end if (!(Test-Path -Path $LogPath))
}   # end f_ValidateLogFilePath


function f_BasicServerInformation {
   # Get basic server version information.
   # https://docs.microsoft.com/en-us/exchange/new-features/build-numbers-and-release-dates?view=exchserver-2019
   Write-Host -NoNewline "Status :  Gathering basic Exchange server information...  "
   $ExchangeServers = Get-ExchangeServer
   Set-Content -Path "$($LogPath)ExchangeServerVersions.csv" -Value "Name,Edition,AdminDisplayVersion"
   foreach ($Server in $ExchangeServers) {
      Add-Content -Path "$($LogPath)ExchangeServerVersions.csv" -Value "$($Server.Name),$($Server.Edition),$($Server.AdminDisplayVersion)"
   }   # end foreach ($Server in $ExchangeServers)
   $ExchangeVersion = Get-Command ExSetup | foreach {$_.FileVersionInfo}
   Set-Content -Path "$($LogPath)ExchangeServerVersions.txt" -Value $ExchangeVersion
   Write-Host "completed."
}   # end function f_BasicServerInformation


function f_DomainsInformation {
   # Get Accepted Domains information.
   Write-Host -NoNewline "Status :  Gathering Accepted Domains information...  "
   $AcceptedDomains = Get-AcceptedDomain
   $LogFile = "$($LogPath)AcceptedDomains_v1.csv"
   $AcceptedDomains | Export-Csv -NoTypeInformation -Path $LogFile
   Write-Host "completed."
}   # end function f_DomainsInformation


function f_AddressListInformation {
   # Get Address List information.
   Write-Host -NoNewline "Status :  Gathering address list information...  "
   $ALs = Get-AddressList
   $LogFile = "$($LogPath)AddressLists_v1.txt"
   $ALs | fl > $LogFile
   $LogFile = "$($LogPath)AddressLists_v1.csv"
   $Header = "DisplayName,Name,Path,Id,Identity,RecipientFilterType,RecipientFilter,LdapRecipientFilter"
   Set-Content -Path $LogFile -Value $Header
   foreach ($AL in $ALs) {
      $Line = "`"$($AL.DisplayName)`",`"$($AL.Name)`",`"$($AL.Path)`",`"$($AL.Id)`",`"$($AL.Identity)`",`"$($AL.RecipientFilterType)`",`"$($AL.RecipientFilter)`",`"$($AL.LdapRecipientFilter)`""
      Add-Content -Path $LogFile -Value $Line
   }   # end foreach ($AL in $ALs)
   Write-Host "completed."
}   # end function f_AddressListInformation


function f_VirtualDirectoryInformation {
   # Get virtual directory information.
   Write-Host -NoNewline "Status :  Gathering virtual directory information...  "
   Get-OwaVirtualDirectory          | fl > "$($LogPath)VirtualDirectory_OWA_v1.txt"
   Get-EcpVirtualDirectory          | fl > "$($LogPath)VirtualDirectory_ECP_v1.txt"
   Get-OabVirtualDirectory          | fl > "$($LogPath)VirtualDirectory_OAB_v1.txt"
   Get-ActiveSyncVirtualDirectory   | fl > "$($LogPath)VirtualDirectory_AS_v1.txt"
   Get-WebServicesVirtualDirectory  | fl > "$($LogPath)VirtualDirectory_WS_v1.txt"
   Get-ClientAccessService          | fl > "$($LogPath)VirtualDirectory_CAS_v1.txt"
   Get-AutodiscoverVirtualDirectory | fl > "$($LogPath)VirtualDirectory_AD_v1.txt"
   Get-PowerShellVirtualDirectory   | fl > "$($LogPath)VirtualDirectory_PS_v1.txt"
   # Get other client and connection-related information.
   Get-RpcClientAccess              | fl > "$($LogPath)RpcClientAccess_v1.txt"
   Get-ExchangeCertificate          | fl > "$($LogPath)Certificates_v1.txt"
   Write-Host "completed."
}   # end function f_VirtualDirectoryInformation


function f_ConnectorInformation {
   # Get Receive Connector information.
   Write-Host -NoNewline "Status :  Gathering Receive Connector information...  "
   $RCs = Get-ReceiveConnector
   foreach ($RC in $RCs) {
      $IPs = $RC.RemoteIPRanges.Expression -join ","
      Add-Member -InputObject $RC -Name "RemoteIPRanges_full" -MemberType NoteProperty -Value $IPs
   }   # end foreach ($RC in $RCs)
   $RCs | Export-Csv -NoTypeInformation -Path "$($LogPath)ConnectorsReceive_v1.csv"
   Write-Host "completed."
   # Get Send Connector information.
   Write-Host -NoNewline "Status :  Gathering Send Connector information...  "
   $SCs = Get-SendConnector
   foreach ($SC in $SCs) {
      $SmartHosts = $SC.SmartHosts -join ","
      $AddressSpaces = $SC.AddressSpaces -join ","
      $ConnectedDomains = $SC.ConnectedDomains -join ","
      $SourceTransportServers = $SC.SourceTransportServers -join ","
      Add-Member -InputObject $SC -Name "SmartHosts_full" -MemberType NoteProperty -Value $SmartHosts
      Add-Member -InputObject $SC -Name "AddressSpaces_full" -MemberType NoteProperty -Value $AddressSpaces
      Add-Member -InputObject $SC -Name "ConnectedDomains_full" -MemberType NoteProperty -Value $ConnectedDomains
      Add-Member -InputObject $SC -Name "SourceTransportServers_full" -MemberType NoteProperty -Value $SourceTransportServers
   }   # end foreach ($SC in $SCs)
   $SCs | Export-Csv -NoTypeInformation -Path "$($LogPath)ConnectorsSend_v1.csv"
   Write-Host "completed."
}  # end function f_ConnectorInformation


function f_TransportRules {
   # Get Transport Rules information.
   Write-Host -NoNewline "Status :  Gathering Transport Rule information...  "
   $AllRules = (Get-TransportRule -ResultSize Unlimited | Sort-Object -Property Name)
   $LogFile = "$($LogPath)TransportRules_v1.txt"
   $AllRules | fl > $LogFile
   $LogFile = "$($LogPath)TransportRules_v1.csv"
   $AllRules | Export-Csv -NoTypeInformation -Path $LogFile
   Write-Host "completed."
}   # end function f_TransportRules


function f_FilterRules {
   # Get Malware Filter information.
   Write-Host -NoNewline "Status :  Gathering Malware Filter information...  "
   $AllMalwareFilters = (Get-MalwareFilterPolicy | Sort-Object -Property Name)
   $LogFile = "$($LogPath)FiltersMalware_v1.csv"
   foreach ($Filter in $AllMalwareFilters) {
      $FileTypes = $Filter.FileTypes -join ","
      Add-Member -InputObject $Filter -MemberType NoteProperty -Name FileTypes_full -Value $FileTypes
   }   # end foreach ($Filter in $AllMalwareFilters)
   $AllMalwareFilters | Export-Csv -NoTypeInformation -Path $LogFile
   Write-Host "completed."
}   # end function f_FilterRules


function f_MailboxStatistics {
   # Get mailbox statistics and sizing.
   Write-Host -NoNewline "Status :  Gathering mailbox statistics and sizing information...  "
   Get-MailboxDatabase | fl > "$($LogPath)MailboxDatabases_v1.txt"
   $MailboxesAll = (Get-Mailbox -ResultSize Unlimited | Sort-Object -Property DisplayName)
   $LogFile = "$($LogPath)MailboxData_v1.csv"
   $HeaderRow = "DisplayName,Name,GivenName,Surname,UserPrincipalName,Alias,SamAccountName,DistinguishedName,PrimarySmtpAddress,EmailAddresses,MailboxSizeMB,ArchiveSizeMB,Office,Title,RecipientType,RecipientTypeDetails,IsMailboxEnabled,LastLogonTime"
   Set-Content -Path $LogFile -Value $HeaderRow
   foreach ($Mailbox in $MailboxesAll) {
      $ADUser = Get-ADUser -Identity $Mailbox.DistinguishedName -Properties Title
      $Stats = Get-MailboxStatistics -Identity $Mailbox.DistinguishedName
      $Size = $Stats.TotalItemSize.Value.ToMB()
      if ($Stats.LastLogonTime -ne $null) {
         $MBlogon = Get-Date -Date $Stats.LastLogonTime -Format "yyyy-MM-dd"
      }   # end if ($Stats.LastLogonTime -ne $null)
      else {
         $MBlogon = ""
      }   # end else
      $EmailAddresses = @()
      foreach ($Address in $Mailbox.EmailAddresses) {
         if ($Address.PrefixString -eq "smtp") {
            $EmailAddresses += $Address.SmtpAddress
         }   # end if ($Address.PrefixString -eq "smtp")
      }   # end foreach ($Address in $Mailbox.EmailAddresses)
      $EmailAddresses = $EmailAddresses -join ","
      if ($Mailbox.ArchiveDatabase -ne $null) {
         $MBArchive = Get-MailboxStatistics -Identity $Mailbox.DistinguishedName -Archive
         $MBAsize = $MBArchive.TotalItemSize.Value.ToMB()
      }   # end if ($Mailbox.ArchiveDatabase -ne $null)
      else {
         $MBAsize = "N/A"
      }   # end else
      $Line = "`"$($Mailbox.DisplayName)`",`"$($Mailbox.Name)`",`"$($ADUser.GivenName)`",`"$($ADUser.Surname)`",`"$($Mailbox.UserPrincipalName)`",`"$($Mailbox.Alias)`",`"$($Mailbox.SamAccountName)`",`"$($Mailbox.DistinguishedName)`",`"$($Mailbox.PrimarySmtpAddress)`",`"$($EmailAddresses)`",`"$($Size)`",`"$($MBAsize)`",`"$($Mailbox.Office)`",`"$($ADUser.Title)`",`"$($Mailbox.RecipientType)`",`"$($Mailbox.RecipientTypeDetails)`",`"$($Mailbox.IsMailboxEnabled)`",`"$($MBlogon)`""
      Add-Content -Path $LogFile -Value $Line
   }   # end foreach ($Mailbox in $MailboxesAll)
   Write-Host "completed."
}   # end function f_MailboxStatistics


function f_MailboxDelegates {
   # Get mailbox delegate access permissions.
   Write-Host -NoNewline "Status :  Gathering mailbox delegate information...  "
   $AllMailboxes       = (Get-Mailbox -ResultSize Unlimited                                        | Sort-Object -Property DisplayName)
   $AllMailboxesUsers  = (Get-Mailbox -ResultSize Unlimited -RecipientTypeDetails UserMailbox      | Sort-Object -Property DisplayName)
   $AllMailboxesEquip  = (Get-Mailbox -ResultSize Unlimited -RecipientTypeDetails EquipmentMailbox | Sort-Object -Property DisplayName)
   $AllMailboxesRooms  = (Get-Mailbox -ResultSize Unlimited -RecipientTypeDetails RoomMailbox      | Sort-Object -Property DisplayName)
   $AllMailboxesShared = (Get-Mailbox -ResultSize Unlimited -RecipientTypeDetails SharedMailbox    | Sort-Object -Property DisplayName)
   # User mailbox permissions.
   $AllMailboxesUsers | Get-MailboxPermission | `
      where {$_.User.ToString() -ne "NT AUTHORITY\SELF" -and $_.IsInherited -eq $false} | `
      select Identity,User,@{Name="AccessRights";Expression={$_.AccessRights -Replace ", ",";"}} | `
      Export-Csv -NoTypeInformation .\MailboxPermissionsUsers_v1.csv
   # Equipment mailbox permissions.
   $AllMailboxesEquip | Get-MailboxPermission | `
      where {$_.User.ToString() -ne "NT AUTHORITY\SELF" -and $_.IsInherited -eq $false} | `
      select Identity,User,@{Name="AccessRights";Expression={$_.AccessRights -Replace ", ",";"}} | `
      Export-Csv -NoTypeInformation .\MailboxPermissionsEquipment_v1.csv
   # Room/Resource mailbox permissions.
   $AllMailboxesRooms | Get-MailboxPermission | `
      where {$_.User.ToString() -ne "NT AUTHORITY\SELF" -and $_.IsInherited -eq $false} | `
      select Identity,User,@{Name="Access Rights";Expression={$_.AccessRights -Replace ", ",";"}} | `
       Export-Csv -NoTypeInformation .\MailboxPermissionsRooms_v1.csv
   # Shared mailbox permissions.
   $AllMailboxesShared | Get-MailboxPermission | `
      where {$_.User.ToString() -ne "NT AUTHORITY\SELF" -and $_.IsInherited -eq $false} | `
      select Identity,User,@{Name="Access Rights";Expression={$_.AccessRights -Replace ", ",";"}} | `
      Export-Csv -NoTypeInformation .\MailboxPermissionsShared_v1.csv
   # Calendar permissions specifically on all mailboxes.
   $LogFile = "$($LogPath)MailboxPermissionsCalendars_v1.csv"
   $Header = "Identity,FolderName,User,AccessRights"
   Set-Content -Path $LogFile -Value $Header
   foreach ($Mailbox in $AllMailboxes) {
      $Perms = Get-MailboxFolderPermission -Identity "$($Mailbox.DistinguishedName):\Calendar"
      foreach ($Perm in $Perms) {
         if ((($Perm.User.ToString() -ne "Default") -or ($Perm.AccessRights -ne "AvailabilityOnly")) -and
             (($Perm.User.ToString() -ne "Anonymous") -or ($Perm.AccessRights -ne "None"))) {
            $Line = "`"$($Perm.Identity)`",`"$($Perm.FolderName)`",`"$($Perm.User)`",`"$($Perm.AccessRights)`""
            Add-Content -Path $LogFile -Value $Line
         }   # end if ((($Perm.User.ToString() -ne "Default") -or...
      }   # end foreach ($Perm in $Perms)
   }   # end foreach ($Mailbox in $AllMailboxes)
   Write-Host "completed."
}   # end function f_MailboxDelegates


function f_ContactObjects {
   # Get Mail Contact object information.
   Write-Host -NoNewline "Status :  Gathering Mail Contact information...  "
   $AllContacts = (Get-Contact -ResultSize Unlimited | Sort-Object -Property DisplayName)
   $LogFile = "$($LogPath)Contacts_MailContacts_v1.csv"
   $Header = "DisplayName,WindowsEmailAddress,Name,FirstName,Initials,LastName,Title,Department,Company,City,RecipientType,RecipientTypeDetails"
   Set-Content -Path $LogFile -Value $Header
   foreach ($Contact in $AllContacts) {
      $Line = "`"$($Contact.DisplayName)`",`"$($Contact.WindowsEmailAddress)`",`"$($Contact.Name)`",`"$($Contact.FirstName)`",`"$($Contact.Initials)`",`"$($Contact.LastName)`",`"$($Contact.Title)`",`"$($Contact.Department)`",`"$($Contact.Company)`",`"$($Contact.City)`",`"$($Contact.RecipientType)`",`"$($Contact.RecipientTypeDetails)`""
      Add-Content -Path $LogFile -Value $Line
   }   # end foreach ($Contact in $AllContacts)
   Write-Host "completed."
   # Get Mail User object information.
   Write-Host -NoNewline "Status :  Gathering Mail User information...  "
   $AllMailUsers = (Get-MailUser -ResultSize Unlimited | Sort-Object -Property DisplayName)
   $LogFile = "$($LogPath)Contacts_MailUsers_v1.csv"
   $Header = "DisplayName,PrimarySmtpAddress,Name,UserPrincipalName,Alias,RecipientType,RecipientTypeDetails,HiddenFromAddressListsEnabled"
   Set-Content -Path $LogFile -Value $Header
   foreach ($MailUser in $AllMailUsers) {
      $Line = "`"$($MailUser.DisplayName)`",`"$($MailUser.PrimarySmtpAddress)`",`"$($MailUser.Name)`",`"$($MailUser.UserPrincipalName)`",`"$($MailUser.Alias)`",`"$($MailUser.RecipientType)`",`"$($MailUser.RecipientTypeDetails)`",`"$($MailUser.HiddenFromAddressListsEnabled)`""
      Add-Content -Path $LogFile -Value $Line
   }   # end foreach ($MailUser in $AllMailUsers)
   Write-Host "completed."
}   # end function f_ContactObjects


function f_DistributionGroups {
   # Get Distribution Group information.
   Write-Host -NoNewline "Status :  Gathering Distribution Group information...  "
   $DistGroups = (Get-DistributionGroup | Sort-Object -Property DisplayName)
   $LogFile = "$($LogPath)DistributionGroups_v1.csv"
   foreach ($DL in $DistGroups) {
      $ManagedBy = $DL.ManagedBy -join ","
      $ManagedByDetails = $DL.ManagedByDetails -join ","
      $EmailAddresses = $DL.EmailAddresses -join ","
      $MemberList = Get-DistributionGroupMember -Identity $DL.DistinguishedName
      if ($MemberList -ne $null) {
         $Members = @()
         foreach ($Member in $MemberList) {
            $Members += $Member.PrimarySmtpAddress
         }   # end foreach ($Member in $MemberList)
         $Members = $Members -join ","
      }   # end if ($MemberList -ne $null)
      else {
         $Members = ""
      }   # end else
      Add-Member -InputObject $DL -MemberType NoteProperty -Name "ManagedBy_full" -Value $ManagedBy
      Add-Member -InputObject $DL -MemberType NoteProperty -Name "ManagedByDetails_full" -Value $ManagedByDetails
      Add-Member -InputObject $DL -MemberType NoteProperty -Name "EmailAddresses_full" -Value $EmailAddresses
      Add-Member -InputObject $DL -MemberType NoteProperty -Name "Members" -Value $Members
   }   # end foreach ($DL in $DistGroups)
   $DistGroups | Export-Csv -NoTypeInformation -Path $LogFile
   Write-Host "completed."
}   # end function f_DistributionGroups


function f_GetPublicFolderStatistics {
   $PFs = Get-PublicFolder -Recurse
   $PFs | Export-Csv -Path ".\PublicFolders.csv" -Recurse
   $PFStats = @()
   foreach ($PF in $PFs) {
      $PFStats += Get-PublicFolderStatistics -Identity $PF.Identity
   }   # end foreach ($PF in $PFs)
   $PFStats | Export-Csv -Path ".\PublicFolderStatistics.csv" -NoTypeInformation
}   # end function f_GetPublicFolderStatistics


#============================================         MAIN PROGRAM         ============================================#
$TimeDate = Get-Date -Format "yyyy-MM-dd HH:mm"
Write-Host -ForegroundColor Green -NoNewline "`nSTATUS :  "
Write-Host "Script processing started at $($TimeDate)."
# Validate the AD module is available.
f_ValidateAdModule
# Validate the Exchange Management Shell (EMS) is running.
f_ValidateEMS
# Validate the log file path exists.  If not, create it.
f_ValidateLogFilePath
# Get basic server version information
f_BasicServerInformation
# Get Accepted and Remote Domains information.
f_DomainsInformation
# Get Address List info
f_AddressListInformation
# Get virtual directory information.
f_VirtualDirectoryInformation
# Get Send/Receive Connector information.
f_ConnectorInformation
# Get Transport Rules information.
f_TransportRules
# Get Malware, Connection, and Spam Filter information.
f_FilterRules
# Get mailbox statistics and sizing.
f_MailboxStatistics
# Get mailbox delegate access permissions.
f_MailboxDelegates
# Get Mail Contact and Mail User information.
f_ContactObjects
# Get Distribution Group information.
f_DistributionGroups
$TimeDate = Get-Date -Format "yyyy-MM-dd HH:mm"
Write-Host -ForegroundColor Green -NoNewline "STATUS :  "
Write-Host "Script processing ended at $($TimeDate).`n"
#============================================        END MAIN PROGRAM      ============================================#
